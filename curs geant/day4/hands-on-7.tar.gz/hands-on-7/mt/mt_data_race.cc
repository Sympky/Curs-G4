//
//
//

// BUILD FLAGS: 
//
// LINUX:
//      g++ -W -Wall -std=c++11 -O2 -g -pthread mt_data_race.cc -o mt_data_race
//
// OS X:
//      clang++ -W -Wall -std=c++11 -stdlib=c++ -O2 -g -pthread mt_data_race.cc -o mt_data_race
//

#include <iostream>
#include <iomanip>
#include <thread>
#include <vector>
#include <sstream>

#ifndef G4MULTITHREADED
#   define G4MULTITHREADED
#endif

#include "G4atomic.hh"

int num_iter = 50000000;
int num_threads = 1;
std::vector<std::thread> threads;

//============================================================================//
void process_args(int, char**);
void check_result(int sum);
//============================================================================//

int main(int argc, char** argv)
{
    process_args(argc, argv);

    int mySum = 0;
    //G4atomic<int> mySum(0); // thread-safe

    //------------------------------------------------------------------------//
    auto MyFunction = [&mySum] () 
    {
        for(int i = 0; i < num_iter; ++i)
            mySum += 1;            
    };
    //------------------------------------------------------------------------//
    /*auto MyFastFunction = [&mySum] () 
    {
        int localSum = 0;
        for(int i = 0; i < num_iter; ++i)
            localSum += 1;            
        mySum += localSum;
    };*/
    //------------------------------------------------------------------------//
    
    std::cout << "\nRunning " << num_threads << " threads ...\n" << std::endl;
    threads.resize(num_threads);
    for(int i = 0; i < num_threads; ++i) // create threads
        threads[i] = std::move(std::thread(MyFunction));

    for(auto& t : threads)
        t.join(); // wait for threads to finish

    check_result(mySum);    
}

//============================================================================//
// Function to convert a string into a number
template <typename _Tp>
_Tp s2n(const std::string& _str)
{
    std::istringstream iss(_str);
    _Tp val = _Tp();
    iss >> val;
    return val;
}
//============================================================================//
void process_args(int argc, char** argv)
{
    if(argc > 1)
    {
        num_threads = s2n<int>(argv[1]);
        if(argc > 2)
            num_iter = s2n<int>(argv[2]);
    }
}
//============================================================================//
void check_result(int sum)
{
    int correct_answer = num_threads * num_iter;
    // If there was no data race, "sum" should equal "correct_answer"
    std::cout << "\n=============================================" << std::endl;
    if(sum != correct_answer)   
    {     
        std::stringstream ss;
        ss << "WARNING! ";
        ss << "The computed value is " << sum << ".\n However, it should be "
           << correct_answer << ".\n The application is not thread-safe." 
           << std::endl;
        //throw std::runtime_error(ss.str());
        std::cerr << ss.str() << std::endl;
        std::cerr << "NOTE: The application did NOT crash, the\n answer was "
                  << "simply just WRONG and no warning\n was given."
                  << std::endl;
    } else
    {
        std::cout << "The application computed the correct result.\nApplication "
                  << "appears to be thread-safe:\n  "
                  << sum << " vs. " << correct_answer << std::endl;    
    }
    std::cout << "=============================================\n" << std::endl;
}
//============================================================================//

